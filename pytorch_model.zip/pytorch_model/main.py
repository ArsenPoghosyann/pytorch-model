from train import parse_conll03
from vocabulary import Vocabulary
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

label_to_id = {
    "O": 0,
    "B-PER": 1,
    "I-PER": 2,
    "B-LOC": 3,
    "I-LOC": 4,
    "B-ORG": 5,
    "I-ORG": 6
}

tokens, labels, maxLength = parse_conll03("train.conll03")

vocab = Vocabulary()
vocab.build(tokens)

for i in range(len(labels)) :
  for j in range(maxLength - len(labels[i])):
    labels[i].append(-100)

embeddings = nn.Embedding(
  num_embeddings=len(vocab.token_to_id),
  embedding_dim=64
)

token_ids = []
for sentence in tokens:
  ids = vocab.encode(sentence)
  token_ids.append(ids)

for sentence in token_ids:
    while len(sentence) < maxLength:
        sentence.append(0)

input_ids = torch.tensor(
    token_ids,
    dtype=torch.long
)

target = torch.tensor(
    labels,
    dtype=torch.long
)

dataset = TensorDataset(
   input_ids,
   target
)

dataloader = DataLoader(
   dataset,
   batch_size=32,
   shuffle=True
)

lstm = nn.LSTM(
    input_size=64,
    hidden_size=128,
    num_layers=2,
    batch_first=True,
    bidirectional=True
)

linear = nn.Linear(256,7)

criterion = nn.CrossEntropyLoss(ignore_index=-100)

optimizer = torch.optim.Adam(
    list(embeddings.parameters()) +
    list(lstm.parameters()) +
    list(linear.parameters()),
    lr=0.001
)

epochs = 15

for epoch in range(epochs):
    embeddings.train()
    lstm.train()
    linear.train()

    total_loss = 0.0

    for batch_input_ids, batch_target in dataloader:
        optimizer.zero_grad()

        vectors = embeddings(batch_input_ids)

        lstm_output, _ = lstm(vectors)

        output = linear(lstm_output)

        output_for_loss = output.permute(0, 2, 1)

        loss = criterion(
            output_for_loss,
            batch_target
        )

        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    average_loss = total_loss / len(dataloader)

    print(
        f"Epoch {epoch + 1}/{epochs} "
        f"Loss: {average_loss:.4f}"
    )

torch.save({
    "embedding": embeddings.state_dict(),
    "lstm": lstm.state_dict(),
    "linear": linear.state_dict(),
    "token_to_id": vocab.token_to_id,
    "id_to_token": vocab.id_to_token,
    "label_to_id": label_to_id,
    "maxLength": maxLength,
    "embedding_dim": 64,
    "hidden_size": 128,
    "num_labels": len(label_to_id)
}, "ner_model.pth")

id_to_label = {
    idx: label
    for label, idx in label_to_id.items()
}

embeddings.eval()
lstm.eval()
linear.eval()

txt = input("Գրեք նախադասությունը ")

text_spl = txt.split()

ids = vocab.encode(text_spl)

real_length = min(len(ids), maxLength)

ids = ids[:maxLength]

while len(ids) < maxLength:
    ids.append(0)

input_tensor = torch.tensor(
    [ids],
    dtype=torch.long
)

with torch.no_grad():
    vectors = embeddings(input_tensor)

    lstm_output, _ = lstm(vectors)

    output = linear(lstm_output)

    predictions = output[0].argmax(dim=-1)

for token, pred_id in zip(
    text_spl[:real_length],
    predictions[:real_length].tolist()
):
    label = id_to_label[pred_id]
    print(f"{token}: {label}")