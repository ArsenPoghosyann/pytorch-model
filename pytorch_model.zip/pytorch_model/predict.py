import torch
import torch.nn as nn

from vocabulary import Vocabulary


checkpoint = torch.load(
    "ner_model.pth",
    weights_only=False
)

vocab = Vocabulary()

vocab.token_to_id = checkpoint["token_to_id"]
vocab.id_to_token = checkpoint["id_to_token"]

label_to_id = checkpoint["label_to_id"]
maxLength = checkpoint["maxLength"]

embedding_dim = checkpoint["embedding_dim"]
hidden_size = checkpoint["hidden_size"]
num_labels = checkpoint["num_labels"]


# Crear las capas
embeddings = nn.Embedding(
    len(vocab.token_to_id),
    embedding_dim
)

lstm = nn.LSTM(
    input_size=embedding_dim,
    hidden_size=hidden_size,
    num_layers=2,
    batch_first=True,
    bidirectional=True
)

linear = nn.Linear(
    hidden_size * 2,
    num_labels
)

embeddings.load_state_dict(
    checkpoint["embedding"]
)

lstm.load_state_dict(
    checkpoint["lstm"]
)

linear.load_state_dict(
    checkpoint["linear"]
)

embeddings.eval()
lstm.eval()
linear.eval()

id_to_label = {
    idx: label
    for label, idx in label_to_id.items()
}

txt = input("Գրեք նախադասությունը: ")

text_spl = txt.split()

ids = vocab.encode(text_spl)

real_length = min(
    len(ids),
    maxLength
)

ids = ids[:maxLength]

while len(ids) < maxLength:
    ids.append(0)

input_tensor = torch.tensor(
    [ids],
    dtype=torch.long
)

with torch.no_grad():

    vectors = embeddings(input_tensor)

    lstm_output, _ = lstm(vectors)

    output = linear(lstm_output)

    predictions = output[0].argmax(dim=-1)

print("\nResult:\n")

for token, pred_id in zip(
    text_spl[:real_length],
    predictions[:real_length].tolist()
):

    label = id_to_label[pred_id]

    print(f"{token:<20} → {label}")
