class Vocabulary:

    def __init__(self):
        self.token_to_id = {
            "<PAD>": 0,
            "<UNK>": 1
        }

        self.id_to_token = {
            0: "<PAD>",
            1: "<UNK>"
        }

    def build(self, sentences):

        for sentence in sentences:
            
            for token in sentence:

                if token not in self.token_to_id:

                    idx = len(self.token_to_id)

                    self.token_to_id[token] = idx
                    self.id_to_token[idx] = token

    def encode(self, tokens):

        return [
            self.token_to_id.get(token, self.token_to_id["<UNK>"])
            for token in tokens
        ]

    def decode(self, ids):

        return [
            self.id_to_token[id]
            for id in ids
        ]