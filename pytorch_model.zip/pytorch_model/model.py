import torch
import torch.nn as nn

class NERModel(nn.Module):
  def __int__(self, vocab_size, embedding_dim, hidden_size, num_classes):
    super().__init__()
    self.embedding = nn.Embedding(
      num_embeddings=vocab_size,
      embedding_dim=embedding_dim
    )

    self.lstm = nn.LSTM(
      input_size=embedding_dim,
      hidden_size=hidden_size,
      num_layers=2,
      batch_first=True,
      bidirectional=True
    )

    self.linear = nn.Linear(
      hidden_size*2,
      num_classes
    )

  def forward(self, input_ids):
    vectors = self.embedding(input_ids)
    lstm_output, _ = self.lstm(vectors)
    output = self.linear(lstm_output)
    return output

