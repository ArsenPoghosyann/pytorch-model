label_to_id = {
    "O": 0,
    "B-PER": 1,
    "I-PER": 2,
    "B-LOC": 3,
    "I-LOC": 4,
    "B-ORG": 5,
    "I-ORG": 6
}

def parse_conll03(file_path):
    tokens = [[]]
    labels = [[]]
    maxLength = 0;
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            spliten = line.split();
            if not line or line.startswith("-DOCSTART-"):
                if len(tokens[-1]) > maxLength:
                    maxLength = len(tokens[-1])
                tokens.append([])
                labels.append([])
                continue
            tokens[-1].append(spliten[0])
            labels[-1].append(label_to_id[spliten[-1]]);
    return tokens, labels, maxLength